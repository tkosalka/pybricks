from pybricks.hubs import MoveHub
from pybricks.pupdevices import Motor, ColorDistanceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = MoveHub()


# Initialize the sensor.
sensor = ColorDistanceSensor(Port.F)

while True:
    # Read the color.
    color1 = sensor.color

    # Print the measured color.
    print(color1)

    # Move the sensor around and see how
    # well you can detect colors.

    # Wait so we can read the value.
    wait(100)

# Turn the light on and off 5 times.
for i in range(10):

    hub.light.on(Color.RED)
    wait(50)
    hub.light.off()
    wait(5)

    hub.light.on(Color.BLUE)
    wait(20)
    hub.light.off()
    wait(5)

    hub.light.on(Color.WHITE)
    wait(20)
    hub.light.off()
    wait(5)
ColorDistanceSensor.detectable_colors()
